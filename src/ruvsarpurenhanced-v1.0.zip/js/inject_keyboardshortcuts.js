document.onkeyup = function(e) {

  // Execute this on player page
  if( window.location.href.indexOf('/sjonvarp/spila/') !== -1 || window.location.href.indexOf('/sjonvarp/beint') !== -1){
    handle_keyup_for_playerpage(e);
    return;
  }

  // Only execute this on list view pages
  if( window.location.href.indexOf('/sjonvarp/spila/') === -1 && window.location.href.indexOf('/sjonvarp/beint') === -1){
    handle_keyup_for_listpage(e);
    return;
  }
}

function handle_keyup_for_playerpage(e) {
  if (e.which == 39) {  // Arrow right
    console.log("Fast forward")
    window.THEOplayer.players[0].currentTime = window.THEOplayer.players[0].currentTime + 90
  } else if (e.which == 37) {  // Arrow left
    console.log("Rewind")
    window.THEOplayer.players[0].currentTime = window.THEOplayer.players[0].currentTime - 60
  } else if (e.which == 70) { //F
    console.log("Fullscreen toggle")
    if( window.THEOplayer.players[0].presentation.currentMode === 'fullscreen' )
      window.THEOplayer.players[0].presentation.requestMode('inline')
    else
      window.THEOplayer.players[0].presentation.requestMode('fullscreen')
  } else if (e.which == 77) { //M
    console.log("Toggle muted")
    window.THEOplayer.players[0].muted = !window.THEOplayer.players[0].muted
  } else if (e.which == 80) {  //P
  console.log("Toggle play/pause")
  if( window.THEOplayer.players[0].paused )
    window.THEOplayer.players[0].play()
  else
    window.THEOplayer.players[0].pause()
  } else if (e.which == 83) { //S
    console.log("Subtitles toggled")
    if( window.THEOplayer.players[0].textTracks.length <= 0 )
      return;
    if( window.THEOplayer.players[0].textTracks[0].mode === 'showing' )
      window.THEOplayer.players[0].textTracks[0].mode = 'disabled'
    else
      window.THEOplayer.players[0].textTracks[0].mode = 'showing'
  } 
  else if( e.which == 66 ) { //B => Back action
    history.back();
  }
};

function handle_keyup_for_listpage(e) {
  // First find the currently selected card, or select the first one
  var selCard = findSelectedCard();
  if( !selCard || selCard.length <= 0 ){
    // If none then the attempt to return the first card div in the page
    handle_selectFirstCard();
    return;
  }
  // Force it to a jQuery selector
  selCard = $(selCard);

  switch(e.which){
    case 39: // Right
      handle_NavigateToNext(selCard);
      break;
    case 37: // Left
      handle_NavigateToPrevious(selCard);
      break;
    case 38: // Up
      handle_NavigateUp(selCard);
      break;
    case 40: // Down
      handle_NavigateDown(selCard);
      break;
    case 80: // P => play event
      perform_clickOnCard(selCard);
      break;
    case 66: // B => Refresh window
      window.location.reload();
      break;
    default:
      return;
  }
};

function findSelectedCard(){
  // First with our class assigned
  var el = $('div.card-selected');
  if( !el || el.length <= 0 ){
    return null;
  }

  // Always just return the first one in case of multiples
  return el.first();  
}

function handle_selectFirstCard(){
  select_card($($('div.card')[0]));
}

function perform_clickOnCard(cardEl){
  // The card contains a <a href> find it and simulate a click event
  var aEl = cardEl.find('a');
  if( !aEl || aEl.length <= 0 )
    return;

  // Fire the event on the first a found
  eventFire( aEl.first() , 'click');
}

function trigger_scroll_list(currCardEl, direction){
  var groupEl = currCardEl.closest('div.slick-list')
  var arrow = groupEl.next('div.slick-next');
  if( direction == 'prev'){
    arrow = groupEl.prev('div.slick-prev');
  }
  
  if( !arrow || arrow.length <= 0)
    return; // Nothing to click don't do anything
    
  eventFire( $(arrow.first()) , 'click');
}

function handle_NavigateToNext(currCardEl){
  // Default is to find next
  var nextEl = currCardEl.next('div.card');

  // If this card is a 'card-featured-single' then we find the nearest 'card-featured-many' and search from there
  if( currCardEl.hasClass('card-featured-single')){
    nextEl = currCardEl.next('div.card-featured-many').find('div.card').first()
  } else {
    // If there is no next el, attempt to click the arrow-next and select again
    if( !nextEl || nextEl.length <= 0){
      trigger_scroll_list(currCardEl, 'next');
    }
    // Now attempt to find the next
    var nextEl = currCardEl.next('div.card');
    if( !nextEl || nextEl.length <= 0){
      return;
    }
  }

  // Perform a selection with what we've got
  select_card(nextEl, currCardEl, 'next');
}

function handle_NavigateToPrevious(currCardEl){
  // Default is to find next
  var prevEl = currCardEl.prev('div.card');

  // If we're navigating away from a billboard many to single then do that
  // If this card is a 'card-featured-single' then we find the nearest 'card-featured-many' and search from there
  if( (!prevEl || prevEl.length <= 0) && currCardEl.parent().hasClass('card-featured-many')){
    prevEl = currCardEl.parent().prev('div.card-featured-single').first()
  } else {
    // If there is no next el, don't do anything more if the prev el has attribute data-index < 0
    // meaning that it is the first card and everything will loop back
    if( currCardEl.prev('div').hasClass('data-index') && parseInt(currCardEl.prev('div').attr('data-index')) < 0 ){
      return;
    }

    // If there is no next el, attempt to click the arrow-next and select again
    if( !prevEl || prevEl.length <= 0){
      trigger_scroll_list(currCardEl, 'prev');
    }
    // Now attempt to find the next
    var prevEl = currCardEl.prev('div.card');
    if( !prevEl || prevEl.length <= 0){
      return;
    }
  }

  // Perform a selection with what we've got
  select_card(prevEl, currCardEl, 'prev');
}

function handle_NavigateUp(currCardEl){
  // First try to find the parent slider
  var groupEl = currCardEl.closest('div.card-slider');

  // Store the location of the current card in the groupEl data
  groupEl.data('selected-card', currCardEl);

  // First, if we're in the billboard section then we just simply select the first group found
  if(currCardEl.closest('section.billboard').length > 0){
    // Check if group is visible
    if( !isElementVisible(groupEl)) {
      groupEl.get(0).scrollIntoView();
    }
    return;
  } else {
    groupEl = groupEl.prev('div.card-slider')
    // If the group is null, we might be close to top, so select the billboard
    if( !groupEl || groupEl.length <= 0 )
      groupEl = $('section.billboard').first();
  }
  
  // If no group element
  if( !groupEl || groupEl.length <= 0)
    return;

  // Get the last selected card for the group or simply select the first
  var nextCard = groupEl.data('selected-card');
  if( !nextCard || nextCard.length <= 0 ){
    //nextCard = groupEl.find('div.card').first();
    nextCard = find_first_visible_card_in_group(groupEl);
  }

  select_card(nextCard, currCardEl);

  // Check if group is visible
  if( !isElementVisible(groupEl)) {
    groupEl.get(0).scrollIntoView();
  }
}

function handle_NavigateDown(currCardEl){
  // First try to find the parent slider
  var groupEl = currCardEl.closest('div.card-slider');

  // Store the location of the current card in the groupEl data
  if( groupEl ) groupEl.data('selected-card', currCardEl);

  // First, if we're in the billboard section then we just simply select the first group found
  if(currCardEl.closest('section.billboard').length > 0){
    groupEl = $('div.card-slider').first();
  } else {
    groupEl = groupEl.next('div.card-slider')
  }
  
  // If no group element
  if( !groupEl || groupEl.length <= 0)
    return;

  // Find the first card and select it
  var nextCard = groupEl.data('selected-card');
  if( !nextCard || nextCard.length <= 0 ){
    nextCard = find_first_visible_card_in_group(groupEl);
  }

  select_card(nextCard, currCardEl);

  // Check if group is visible
  if( !isElementVisible(groupEl)){
    groupEl.get(0).scrollIntoView();
  }
}

function find_first_visible_card_in_group(groupEl){
  var firstCard = null;
  groupEl.find('div').each(function(idx, card){
    var cardEl = $(card);

    // If it has class card then assign it
    if( cardEl.hasClass('card') && !firstCard ){
      firstCard = cardEl;
      return;
    }
    
    // if it has attribute data-index with value less than zero then clear firstCard
    if( parseInt(cardEl.attr('data-index')) < 0 ){
      firstCard = null;
      return;
    }

  });
  return firstCard;
}

function select_card(cardEl, prevCardEl, direction){
  if( !cardEl || cardEl.length <= 0 )
    return;

  if(prevCardEl)
    prevCardEl.removeClass('card-selected');

  cardEl.addClass('card-selected');

  // If the currently selected card is off-screen then attempt to bring it into view
  if( direction && !isElementVisible(cardEl)){
    trigger_scroll_list(cardEl, direction);
  }
}

function eventFire(el, etype){
  // If jQuery
  if( el.on ){
    el.get(0).click();
    return;
  }

  // If some fancy fireEvent crap
  if (el.fireEvent) {
    el.fireEvent('on' + etype);
    return;
  }

  // Default handling
  var evObj = document.createEvent('Events');
  evObj.initEvent(etype, true, false);
  el.dispatchEvent(evObj);
}

function isElementVisible(element, partial,hidden,direction,container){

  if (element.length < 1)
      return;

// Set direction default to 'both'.
direction = direction || 'both';

  var $t          = element.length > 1 ? element.eq(0) : element,
      isContained = typeof container !== 'undefined' && container !== null,
      $c				  = isContained ? $(container) : $(window),
      wPosition        = isContained ? $c.position() : 0,
      t           = $t.get(0),
      vpWidth     = $c.outerWidth(),
      vpHeight    = $c.outerHeight(),
      clientSize  = hidden === true ? t.offsetWidth * t.offsetHeight : true;

  if (typeof t.getBoundingClientRect === 'function'){

      // Use this native browser method, if available.
      var rec = t.getBoundingClientRect(),
          tViz = isContained ?
                  rec.top - wPosition.top >= 0 && rec.top < vpHeight + wPosition.top :
                  rec.top >= 0 && rec.top < vpHeight,
          bViz = isContained ?
                  rec.bottom - wPosition.top > 0 && rec.bottom <= vpHeight + wPosition.top :
                  rec.bottom > 0 && rec.bottom <= vpHeight,
          lViz = isContained ?
                  rec.left - wPosition.left >= 0 && rec.left < vpWidth + wPosition.left :
                  rec.left >= 0 && rec.left <  vpWidth,
          rViz = isContained ?
                  rec.right - wPosition.left > 0  && rec.right < vpWidth + wPosition.left  :
                  rec.right > 0 && rec.right <= vpWidth,
          vVisible   = partial ? tViz || bViz : tViz && bViz,
          hVisible   = partial ? lViz || rViz : lViz && rViz,
vVisible = (rec.top < 0 && rec.bottom > vpHeight) ? true : vVisible,
          hVisible = (rec.left < 0 && rec.right > vpWidth) ? true : hVisible;

      if(direction === 'both')
          return clientSize && vVisible && hVisible;
      else if(direction === 'vertical')
          return clientSize && vVisible;
      else if(direction === 'horizontal')
          return clientSize && hVisible;
  } else {

      var viewTop 				= isContained ? 0 : wPosition,
          viewBottom      = viewTop + vpHeight,
          viewLeft        = $c.scrollLeft(),
          viewRight       = viewLeft + vpWidth,
          position          = $t.position(),
          _top            = position.top,
          _bottom         = _top + $t.height(),
          _left           = position.left,
          _right          = _left + $t.width(),
          compareTop      = partial === true ? _bottom : _top,
          compareBottom   = partial === true ? _top : _bottom,
          compareLeft     = partial === true ? _right : _left,
          compareRight    = partial === true ? _left : _right;

      if(direction === 'both')
          return !!clientSize && ((compareBottom <= viewBottom) && (compareTop >= viewTop)) && ((compareRight <= viewRight) && (compareLeft >= viewLeft));
      else if(direction === 'vertical')
          return !!clientSize && ((compareBottom <= viewBottom) && (compareTop >= viewTop));
      else if(direction === 'horizontal')
          return !!clientSize && ((compareRight <= viewRight) && (compareLeft >= viewLeft));
  }
};