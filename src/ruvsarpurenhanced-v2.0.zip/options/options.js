function saveOptions(e) {
  e.preventDefault();
  
  var options = {
    videoQuality: getValue($("#videoQuality")),
    iceSubtitles: getValue($("#iceSubtitles")),
    autoPlayNext: getValue($("#autoPlayNext")),
    startPlayOnLoad: getValue($("#startPlayOnLoad")),
  }

  chrome.storage.sync.set({options},
    function() {
      // Update status to let user know options were saved.
      var status = document.getElementById('status');
      status.textContent = 'Options saved.';
      setTimeout(function() {
        status.textContent = '';
      }, 750);
    });
}

function restoreOptions() {

  function setCurrentChoice(val) {
    if( !val || !val.options) return;

    var result = val.options;
    setValue($("#videoQuality"), result.videoQuality);
    setValue($("#iceSubtitles"), result.iceSubtitles);
    setValue($("#autoPlayNext"), result.autoPlayNext);
    setValue($("#startPlayOnLoad"), result.startPlayOnLoad);
  }

  chrome.storage.sync.get("options", setCurrentChoice);
}

document.addEventListener("DOMContentLoaded", restoreOptions);
$('#savebutton').on('click', saveOptions);

function setValue(el, result){
  if( !result || !result.enabled) return;

  if( el.is(':checkbox') || el.is(':radio')){
    el.prop('checked', result.value === 'true');
  } else if( el.is('select') ){
    el.find("option").removeAttr('selected');
    el.find('option[value="'+result.value+'"]').prop({defaultSelected: true});
  } else {
    el.val(result.value);
  }
  el.change(); // Trigger the change event
}

function getValue(el){
  var val = undefined;

  if( el.is(':checkbox') || el.is(':radio')) {
    if( el.is(':checked') ){
      val = 'true';
    }
  }
  else if( el.is('select') ){
    val = el.find("option:selected" ).val();
  }
  else {
    val = el.val();
  }

  return { 
    enabled: val !== undefined,
    value: val
  }
}