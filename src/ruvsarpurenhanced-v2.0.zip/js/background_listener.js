/*
Change the behavior of the extension icon click
 */
chrome.browserAction.setPopup({popup:''});  //disable browserAction's popup
chrome.browserAction.onClicked.addListener(()=>{
    chrome.tabs.create({url:'options/options.html'});
});

/* 
  Listen to various player change events on the page 
  this is used to track selected bitrate, current location when stopped etc.
*/
chrome.runtime.onMessageExternal.addListener(
  function(request, sender, sendResponse) {

    function checkOptionsSettings(val) {
      if( !val || !val.options) return;
      var options = val.options;

      if( request.settingName in options 
        && options[request.settingName].enabled
        && options[request.settingName].value ){
          sendResponse(options[request.settingName]);
        }
    }

    console.log(request);
    console.log(sender);

    //{type:'checksetting', settingName: settingName}
    if( !request.type) return;

    if( request.type === 'checksetting'){
      chrome.storage.sync.get("options", checkOptionsSettings);
      return;
    }
    
    return true; //Important
  });


