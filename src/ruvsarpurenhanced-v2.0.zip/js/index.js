/**
 * Main entry point for the script loaded on player enabled pages
 * e.g. beint/spila that kind of thing
 */
$( document ).ready(function() {
  injectScript('js/lib/jquery-3.4.1.min.js');
  injectScript("js/lib/jquery.visible.min.js");
  injectScript('js/inject_keyboardshortcuts.js');

  // Write out the current settings for the player and inject them into the page as well

});